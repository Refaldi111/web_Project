function hitungGaji() {
    var jamKerja = parseFloat(document.getElementById('jamKerja').value);
    var tarifPerJam = parseFloat(document.getElementById('tarifPerJam').value);
    var gaji;

    if (jamKerja > 40) {
        var jamLembur = jamKerja - 40;
        gaji = (40 * tarifPerJam) + (jamLembur * tarifPerJam * 1.5);
    } else {
        gaji = jamKerja * tarifPerJam;
    }

    document.getElementById('result').innerHTML = 'Total Gaji Yang Di Dapat: ' + gaji;
}

function downloadFile() {
  
}







